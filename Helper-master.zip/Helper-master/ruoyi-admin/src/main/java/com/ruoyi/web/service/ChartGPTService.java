package com.ruoyi.web.service;

public interface ChartGPTService {

    String send(String prompt);
}
